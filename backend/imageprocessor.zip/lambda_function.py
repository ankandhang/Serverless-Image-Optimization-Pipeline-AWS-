import boto3
from PIL import Image
import io
import os

s3 = boto3.client('s3')

OUTPUT_BUCKET = "image-output-bucket-jhon"

SIZES = {
    "1080p": (1920, 1080),
    "720p": (1280, 720),
    "480p": (854, 480)
}

def lambda_handler(event, context):
    for record in event['Records']:
        input_bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        response = s3.get_object(Bucket=input_bucket, Key=key)
        image = Image.open(response['Body']).convert("RGB")

        for size_name, dimensions in SIZES.items():
            resized = image.copy()
            resized.thumbnail(dimensions)

            buffer = io.BytesIO()
            resized.save(buffer, format="JPEG", quality=80)
            buffer.seek(0)

            output_key = f"{size_name}/{os.path.basename(key)}"

            s3.put_object(
                Bucket=OUTPUT_BUCKET,
                Key=output_key,
                Body=buffer,
                ContentType="image/jpeg"
            )

    return {"statusCode": 200}
